package kz.one.lab.lesson4.services;

import kz.one.lab.lesson4.entity.Fighter;

public interface CheckingDopingService {
    boolean checkFigher(Fighter dude);
}
