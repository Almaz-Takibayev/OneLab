package kz.one.lab.lesson4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson4Application {

	public static void main(String[] args) {
		SpringApplication.run(Lesson4Application.class, args);
	}

}
